var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var studio_api_exports = {};
__export(studio_api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(studio_api_exports);
const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Content-Type": "application/json; charset=utf-8"
};
const SAMPLE_MEMORIES = [
  {
    id: "MEM-001",
    category: "kernel",
    cluster: "Kernel",
    weight: 0.98,
    text: "Spike-Timing-Dependent Plasticity (STDP) biomorphic decay algorithm active in local SQLite vector database.",
    author: "Azoth",
    tags: ["stdp", "synaptic", "decay"]
  },
  {
    id: "MEM-002",
    category: "oracle",
    cluster: "Lucy Oracle",
    weight: 0.99,
    text: "Lucy Cognitive Memory Oracle active on loopback semantic bus. STDP memory indexing continuous cross-session knowledge.",
    author: "Lucy",
    tags: ["memory", "lucy", "oracle"]
  },
  {
    id: "MEM-003",
    category: "consensus",
    cluster: "Consensus",
    weight: 0.94,
    text: "3-Agent Byzantine Triangulation synthesized: Azoth, Chronos, and Athena signed block consensus #8849.",
    author: "Athena",
    tags: ["consensus", "byzantine", "triangulation"]
  },
  {
    id: "MEM-004",
    category: "security",
    cluster: "Security",
    weight: 0.96,
    text: "Zero-Egress enclave verified. Loopback containment active with 0 external tracking endpoints.",
    author: "Lycan",
    tags: ["zero-egress", "entropy", "security"]
  }
];
async function handler(event, context) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS_HEADERS, body: "" };
  }
  const rawPath = event.path || "";
  const subpath = rawPath.replace(/^\/\.netlify\/functions\/studio-api\/?/, "").replace(/^\/api\/studio\/?/, "");
  if (subpath === "status" || subpath === "") {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        environment: "Netlify Hosted Showcase (Zero-Egress Guaranteed)",
        kvm: false,
        services: {
          swarm: {
            name: "Swarm multiplexer",
            port: 8989,
            up: true,
            detail: { mode: "Local Multiplexer", agents: 21 }
          },
          memory: {
            name: "Neuro memory daemon",
            port: 8094,
            up: true,
            detail: { mode: "Netlify Cloud Showcase", vector_count: SAMPLE_MEMORIES.length }
          },
          bridge: {
            name: "Sovereign agent bridge",
            port: 8102,
            up: true,
            detail: { mode: "Netlify Cloud Showcase", agents: 21 }
          },
          azoth: {
            name: "Azoth local agent",
            port: 8790,
            up: true,
            detail: { role: "Prime Alchemist Orchestrator" }
          },
          ollama: {
            name: "Ollama",
            port: 11434,
            up: false,
            models: [],
            note: "Run locally at 127.0.0.1:11434 for offline silicon inference"
          },
          civilization: {
            name: "Zoth civilization",
            port: 9393,
            up: true,
            adytumCycleCount: 4,
            observationalCycles: 4,
            detail: { day: 6, leader: "AZOTH", adytumCycles: 4 }
          }
        }
      })
    };
  }
  if (subpath.startsWith("memory")) {
    const q = (event.queryStringParameters?.q || "").toLowerCase();
    const filtered = q ? SAMPLE_MEMORIES.filter((m) => m.text.toLowerCase().includes(q) || m.id.toLowerCase().includes(q) || m.category.includes(q)) : SAMPLE_MEMORIES;
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        query: q,
        count: filtered.length,
        memories: filtered,
        results: filtered
      })
    };
  }
  if (subpath.startsWith("bridge")) {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        status: "online",
        transport: "WebSocket / Loopback Mesh",
        peers: 21,
        message: "Sovereign Agent Bridge active. Ready for inter-agent consensus packets."
      })
    };
  }
  if (subpath.startsWith("zoth-ai") || subpath.startsWith("model")) {
    let body = {};
    try {
      body = event.body ? JSON.parse(event.body) : {};
    } catch {
    }
    const prompt = (body.prompt || event.queryStringParameters?.prompt || "").trim();
    const model = body.model || "zoth-ai";
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        model: model === "zoth-ai-micro" ? "zoth-ai-micro (SmolLM2 360M)" : "zoth-ai:latest (Qwen 2.5 Coder 1.5B)",
        architecture: "Qwen 2.5 Coder / SmolLM2 Biomorphic Spec",
        inferenceEngine: "WebGPU Tensor Shaders / Sovereign Local Enclave",
        prompt,
        response: prompt ? `[Zoth-AI: Qwen 2.5 Coder 1.5B] Analyzed query "${prompt}". Executing under zero-egress invariants with SHA-256 state seal.` : 'Zoth-AI model daemon ready. Send JSON payload with {"prompt": "..."} to execute.',
        telemetry: {
          egress: "0 bytes",
          latencyMs: 18.4,
          invariants: ["loopback_only", "zero_cloud_tracking", "sha256_sealed"]
        }
      })
    };
  }
  return {
    statusCode: 200,
    headers: CORS_HEADERS,
    body: JSON.stringify({
      endpoint: subpath,
      status: "active",
      architecture: "Zero-Egress Sovereign Enclave"
    })
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
